//package com.example.common
//
//import androidx.appcompat.app.AppCompatActivity
//import android.os.Bundle
//import com.example.common.mvp.base.BaseActivity
//import com.example.common.mvp.presenter.BasePresenter
//
//open class CommonTestActivity : BaseActivity() {
//    override fun getPresenter(): BasePresenter {
//        TODO("Not yet implemented")
//    }
//
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContentView(R.layout.activity_main)
//    }
//
//    override fun initContentId(): Int {
//        TODO("Not yet implemented")
//    }
//
//    override fun initView() {
//        TODO("Not yet implemented")
//    }
//
//    override fun initData() {
//        TODO("Not yet implemented")
//    }
//}
