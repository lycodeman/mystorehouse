package com.example.common.mvp.module

import javax.inject.Inject

class BaseListModule @Inject constructor(): BaseModule(){

}
