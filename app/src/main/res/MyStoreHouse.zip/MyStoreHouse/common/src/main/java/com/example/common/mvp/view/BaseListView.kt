package com.example.common.mvp.view

interface BaseListView : RxRefreshView{

}
