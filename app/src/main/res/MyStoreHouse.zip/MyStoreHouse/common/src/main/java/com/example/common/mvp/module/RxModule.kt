package com.example.common.mvp.module

//import com.genlot.common.mvp.BaseModule
//import com.genlot.hnapp.api.GenLotApis
import javax.inject.Inject
import javax.inject.Provider

/**
 *     Author : 李勇
 *     Create Time   : 2020/08/11
 *     Desc   :
 *     PackageName: com.genlot.hnapp.mvp.module
 */
abstract class RxModule : BaseModule(){

//    @Inject
//    lateinit var mGenLotApis: Provider<GenLotApis>
}