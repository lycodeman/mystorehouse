package com.example.common.mvp.module

import javax.inject.Inject

class EmptyModule @Inject constructor(): BaseModule(){

}
