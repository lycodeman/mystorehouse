//package com.example.mystorehouse
//
//import com.example.common.mvp.base.BaseActivity
//import com.example.common.mvp.presenter.BasePresenter
//
///**
// *     Author : 李勇
// *     Create Time   : 2020/08/25
// *     Desc   :
// *     PackageName: com.example.mystorehouse
// */
//class LoginActivity : BaseActivity() {
//    override fun getPresenter(): BasePresenter {
//        TODO("Not yet implemented")
//    }
//
//    override fun initContentId(): Int {
//        TODO("Not yet implemented")
//    }
//
//    override fun initView() {
//        TODO("Not yet implemented")
//    }
//
//    override fun initData() {
//        TODO("Not yet implemented")
//    }
//}